### If you have an issue with a specific extension or type

Locate the definition for your extension/type in the [db.json file](https://github.com/jshttp/mime-db/blob/master/db.json) in the `mime-db` project.  Does it look right?

- [ ] No. [File a `mime-db` issue](https://github.com/jshttp/mime-db/issues/new).
- [ ] Yes: Go ahead and submit your issue/PR here and I'll look into it.
